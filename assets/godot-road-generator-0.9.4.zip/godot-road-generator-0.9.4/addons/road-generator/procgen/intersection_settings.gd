@tool
@icon("res://addons/road-generator/resources/road_intersection.png")
# @abstract
class_name IntersectionSettings
extends Resource
## Settings for the [RoadIntersection] on which
## this resource is assigned.
##
## @abstract
##
## Defines a [RoadIntersection]'s procedural generation
## (settings, mesh, agent lanes, etc.).
##
## When assigned as default, it should be made unique to avoid
## unexpected side effects on other intersection points when modifying
## the resource.
##
## **Note:** Cannot reference [RoadIntersection] to avoid cyclic dependencies.

# ------------------------------------------------------------------------------
#region Mesh generation
# ------------------------------------------------------------------------------


## @abstract
## returns a Mesh for the intersection based on the input parameters.
##
## The override should return an empty mesh if arrays are empty
## (i.e. the intersection has no points).
##
## Parent transform refers to the [RoadIntersection]'s local transform.
##
## Edges MUST have been sorted by angle from intersection beforehand.
##
## Note: Cannot use [RoadIntersection] for `intersection` due to cyclic typing.
func generate_mesh(intersection: Node3D, edges: Array[RoadPoint], container: RoadContainer) -> Mesh:
	push_error("IntersectionSettings.generate_mesh() not implemented by child class.")
	return null


## @abstract
## Generates the RoadLanes for the intersection, as children of the
## [param intersection] node.
##
## Mirrors [generate_mesh]: triggered by the [RoadIntersection] during rebuild,
## with the concrete subclass deciding the per-type lane connections.
##
## Edges MUST have been sorted by angle from intersection beforehand.
##
## Note: Cannot use [RoadIntersection] for `intersection` due to cyclic typing.
func generate_lanes(intersection: Node3D, edges: Array[RoadPoint], container: RoadContainer) -> void:
	push_error("IntersectionSettings.generate_lanes() not implemented by child class.")


## @abstract
## Generates the exterior edge curves for the intersection, as children of the
## [param intersection] node, one [Path3D] per branch named `edge_{RoadPoint name}`.
##
## Mirrors [generate_lanes]: triggered by the [RoadIntersection] during rebuild,
## with the concrete subclass building the boundary geometry so the curves line
## up with the adjoining [RoadSegment] edge curves.
##
## Edges MUST have been sorted by angle from intersection beforehand.
##
## Note: Cannot use [RoadIntersection] for `intersection` due to cyclic typing.
func generate_edge_curves(intersection: Node3D, edges: Array[RoadPoint], container: RoadContainer) -> void:
	push_error("IntersectionSettings.generate_edge_curves() not implemented by child class.")


## @abstract
## Removes all generated edge curves from the [param intersection] node.
func clear_edge_curves(intersection: Node3D, edges: Array[RoadPoint], container: RoadContainer) -> void:
	push_error("IntersectionSettings.clear_edge_curves() not implemented by child class.")


## Returns true if all the provided edges have sufficient distance
## from the intersection point to have proper mesh generation.
##
## To customize the minimum distance, override [get_min_distance_from_intersection_point].
##
## This should be called in the implemented class's [generate_mesh] override.
func can_generate_mesh(intersection_transform: Transform3D, edges: Array[RoadPoint]) -> bool:
	for edge in edges:
		if not is_instance_valid(edge):
			push_warning("Invalid edge, cannot create intersection")
			return false
		if edge.position.distance_to(intersection_transform.origin) < get_min_distance_from_intersection_point(edge):
			return false
	return true

## Returns the minimum distance required between a [RoadIntersection]
## and its [RoadPoint] edges for the mesh to generate correctly.
func get_min_distance_from_intersection_point(rp: RoadPoint) -> float:
	return 0.0

# ------------------------------------------------------------------------------
#endregion
# ------------------------------------------------------------------------------
