@tool
@icon("res://addons/road-generator/resources/road_container.png")
class_name RoadContainer
extends Node3D
## The parent node for [RoadPoint]'s and controller of actual geo creation.
##
## A Road is defined by a [RoadContainer] with two or more [RoadPoint] children
## who are connected together.
##
## Can be saved as the root of a scene for reuse, otherwise should be placed as
## the child of a [RoadManager] node.
##
## @tutorial(Getting started): https://github.com/TheDuckCow/godot-road-generator/wiki/A-getting-started-tutorial
## @tutorial(Custom Materials Tutorial): https://github.com/TheDuckCow/godot-road-generator/wiki/Creating-custom-materials
## @tutorial(Custom Mesh Tutorial): https://github.com/TheDuckCow/godot-road-generator/wiki/User-guide:-Custom-road-meshes


# ------------------------------------------------------------------------------
#region Signals/Enums/Const
# ------------------------------------------------------------------------------


## Emitted when a road segment has been (re)generated, returning the list
## of updated segments of type Array.
##
## Elements can be either RoadSegments or RoadIntersections. These always have
## a child node which is the mesh of the road itself.
signal on_road_updated(updated_segments: Array[Node3D])

## For internal purposes, to handle drag events in the editor.
signal on_transform(node)

const RoadSegment = preload("res://addons/road-generator/nodes/road_segment.gd")
const RoadMaterial = preload("res://addons/road-generator/resources/road_texture.material")

# ------------------------------------------------------------------------------
# How road meshes are generated
@export_group("Road Generation")
# ------------------------------------------------------------------------------


## Generate procedural road geometry.[br][br]
##
## If off, it indicates the developer will load in their own custom mesh + collision.
@export var create_geo := true: set = _set_create_geo

## Material applied to the generated meshes, expects specific trimsheet UV layout[br][br]
##
## If cleared, will utilize the default specificed by the [RoadManager].
@export var material_resource: Material: set = _set_material

## Override the first material slot for all of these meshes to match RoadContainer top material
@export var material_top_meshes: Array[MeshInstance3D] = []

## Material applied to the underside of the generated meshes[br][br]
##
## If cleared, will utilize the default specificed by the [RoadManager].
@export var material_underside: Material: set = _set_material_underside

## Override the first material slot for all of these meshes to match RoadContainer underside material
@export var material_underside_meshes: Array[MeshInstance3D] = []

## Defines the distance in meters between road loop cuts.[br][br]
##
## This mirrors the same term used in native Curve3D objects where a higher
## density means a larger spacing between loops and fewer overall verticies.[br][br]
##
## A value of -1 indicates the density of the RoadManager will be used, or the
## internal default of 4.0 if no manager is present.
@export var density: float = -1.0: set = _set_density

## Use fewer loop cuts for performance during transform.
@export var use_lowpoly_preview: bool = false

## Flattens terrain underneath when transforming this RoadContainer[br]
## or child RoadPoints if a terrain connector is set up.[br][br]
##
## See RoadTerrain3DConnector node to configure the connection.
## or see this tutorial:[br]
## https://github.com/TheDuckCow/godot-road-generator/wiki/Using-the-Terrain3D-Connector
@export var flatten_terrain: bool = true

## Defines the thickness in meters of the underside part of the road.[br][br]
##
## A value of -1 indicates the thickness of the RoadRoadManager will be used, or the
## underside will not be generated at all.
@export var underside_thickness: float = -1.0: set = _set_thickness

## Render layer to set for the generated road meshes.
@export_flags_3d_render var render_layers: int = 1:
	set(value):
		render_layers = value
		_defer_refresh_on_change()

# ------------------------------------------------------------------------------
# Properties defining how to set up the road's StaticBody3D
@export_group("Collision")
# ------------------------------------------------------------------------------


## The PhysicsMaterial to apply to static bodies.[br][br]
##
## An override for any present on the parent [member RoadManager.physics_material] .
@export var physics_material: PhysicsMaterial:
	set(value):
		physics_material = value
		_defer_refresh_on_change()

## Group name to assign to the staic bodies created within a RoadSegment.
@export var collider_group_name := "": set = _set_collider_group
## Meta property name to assign to the static bodies created within a RoadSegment.
@export var collider_meta_name := "": set = _set_collider_meta

## If enabled, use collision_layer and collision_mask defined on this RoadContainer instead of the [RoadManager].
@export var override_collision_layers:bool = false
## Collision layer to assign to the generated [StaticBody3D]'s own collision_layer.
@export_flags_3d_physics var collision_layer: int = 1:
	set(value):
		collision_layer = value
		_defer_refresh_on_change()
## Collision mask to assign to the generated [StaticBody3D]'s own collision_mask.
@export_flags_3d_physics var collision_mask: int = 1:
	set(value):
		collision_mask = value
		_defer_refresh_on_change()


# ------------------------------------------------------------------------------
# Properties relating to how RoadLanes and AI tooling is set up
@export_group("Lanes and AI")
# ------------------------------------------------------------------------------


## Whether to auto-generate [RoadLane]'s for AI agents to follow.[br][br]
##
## These are extensions of the native 3D Curve, added to the runtime game as a
## child of RoadPoints when connections exist.
@export var generate_ai_lanes := false: set = _set_gen_ai_lanes

## The group name to assign to any procedurally generated [RoadLane]'s.
@export var ai_lane_group := "": set = _set_ai_lane_group

## Setter applied to [RoadLane] on whether to auto-free registered vehicles on _exit_tree.[br][br]
##
## This lets the road generator handle the cleanup of any vehicles listed as
## following a road segment about to be deleted anyways, even when the vehicle
## is not a direct child of the segments being removed.
@export var auto_free_vehicles := true: set = _set_auto_free_vehicles

## Visualize [RoadLane]'s and their directions in the editor directly.
@export var draw_lanes_editor := false: get = _get_draw_lanes_editor, set = _set_draw_lanes_editor
## Visualize [RoadLane]'s and their directions during the game runtime.
@export var draw_lanes_game := false: get = _get_draw_lanes_game, set = _set_draw_lanes_game


# ------------------------------------------------------------------------------
# Properties which assist with further decorating of roads, such as sidewalks
# and railings
@export_group("Decoration")
# ------------------------------------------------------------------------------


## Create approximated curves along the left, right, and center of the road.[br][br]
##
## Exposed in the editor, useful for adding procedural generation along road
## edges or center lane.
@export var create_edge_curves := false: set = _set_create_edge_curves


# ------------------------------------------------------------------------------
# Auto generated exposed variables used to connect this RoadContainer to
# another RoadContainer.
# These should *never* be manually adjusted, they are only export vars to
# facilitate the connection of RoadContainers needing to connect to points in
# different scenes, where said connection needs to be established in the editor.
# TODO: In Godot 4.3ish, these should be @export_storage, hidden to users
# https://github.com/godotengine/godot/pull/82122
@export_group("Internal data")
# ------------------------------------------------------------------------------

## Output additional debug information, does not change functionality.
@export var debug := false

## Considered private, not meant for editor or script interaction.[br][br]
##
## Paths to other containers, relative to this container (self)
@export var edge_containers: Array[NodePath]
## Considered private, not meant for editor or script interaction.[br][br]
##
## Node paths within other containers, relative to the *target* container (not self here)
@export var edge_rp_targets: Array[NodePath]
## Considered private, not meant for editor or script interaction.[br][br]
##
## Direction of which RP we are connecting to, used to make unique key along with
## the edge_rp_targets path above. Enum value of RoadPoint.PointInit
@export var edge_rp_target_dirs: Array[int]
## Considered private, not meant for editor or script interaction.[br][br]
##
## Node paths within this container, relative to this container
@export var edge_rp_locals: Array[NodePath]
## Considered private, not meant for editor or script interaction.[br][br]
##
## Local RP directions, enum value of RoadPoint.PointInit
@export var edge_rp_local_dirs: Array[int]


# ------------------------------------------------------------------------------
#endregion
#region Runtime variables
# ------------------------------------------------------------------------------


## Mapping maintained of individual segments and their corresponding resources.
var segid_map = {}

## Non-exposed developer control, which allows showing all nodes (including generated) in the scene
## tree. Typcially we don't want to do this, so that users don't accidentally start adding nodes
## or making changes that get immediately removed as soon as a road is regenerated.
var debug_scene_visible:bool = false

## Flag used to defer calls to setup_road_container via _dirty_rebuild_deferred,
## important during scene startup whereby class properties are called in
## succession during scene init and otherwise would lead to duplicate calls.
var _dirty:bool = false

## Flag to auto rebuild specific segments under any relevant setting change.
## Default to true, but should be set by the parent RoadManager
var _auto_refresh = true
var _needs_refresh = false

var _draw_lanes_editor:bool = false
var _draw_lanes_game:bool = false

## Refernce to the parent road manager if any.
var _manager:RoadManager

## Edge-related error state
var _edge_error: String = ""

## Variables for internal handling of drag events
## Constants used for adhoc meta tags for internal state assignments
var _drag_init_transform # : Transform3D can't type as it needs to be nullable
var _drag_source_rp: RoadPoint
var _drag_target_rp: RoadPoint


# ------------------------------------------------------------------------------
#endregion
#region Setup and overrides
# ------------------------------------------------------------------------------


func _ready():
	# setup_road_container won't work in _ready unless call_deferred is used
	setup_road_container.call_deferred()

	set_notify_transform(true) # TOOD: check if both of these are necessary
	set_notify_local_transform(true)

	get_manager()
	update_edges()
	validate_edges()

	rebuild_segments(true)


func _enter_tree() -> void:
	# Segments survive a tree exit as RoadPoint children while _exit_tree drops
	# the id map; re-register them so later edits reuse instead of duplicate.
	for seg in get_segments():
		if not is_instance_valid(seg.start_point) or not is_instance_valid(seg.end_point):
			continue
		var sid: String = RoadSegment.get_id_for_points(seg.start_point, seg.end_point)
		if not sid in segid_map or not is_instance_valid(segid_map[sid]):
			segid_map[sid] = seg


## Cleanup the road segments specifically, in case they aren't children.
func _exit_tree():
	# TODO: Verify we don't get orphans below.
	# However, at the time of this early exit, queueing free segments prevented
	# roads from being drawn on scene load due to errors unloading against
	# freed instances.
	segid_map = {}
	return


func _get_configuration_warnings() -> PackedStringArray:
	var warnstr

	if get_tree().get_edited_scene_root() != self:
		var any_manager := false
		var _last_par = get_parent()
		while true:
			if _last_par.get_path() == ^"/root":
				break
			if _last_par.has_method("is_road_manager"):
				any_manager = true
				_last_par._skip_warn_found_rc_child = true
				break
			_last_par = _last_par.get_parent()
		if any_manager == false:
			warnstr = "A RoadContainer should either be the scene root, or have a RoadManager somewhere in its parent hierarchy"
			return [warnstr]

	var has_rp_child = false
	for ch in get_children():
		if ch is RoadPoint:
			has_rp_child = true
			break
	if not has_rp_child:
		warnstr = "Add RoadPoint nodes as children to form a road, or use the Roads menu in the 3D view header"
		return [warnstr]

	if _needs_refresh:
		warnstr = "Refresh outdated geometry by selecting this node and going to 3D view > Roads menu > Refresh Roads"
		return [warnstr]

	if _edge_error != "":
		warnstr = "Refresh roads to clear invalid connections:\n%s" % _edge_error
		return [warnstr]
	return []


## Workaround for cyclic typing
func is_road_container() -> bool:
	return true


## Temp added
func get_owner() -> Node:
	return self.owner if is_instance_valid(self.owner) else self


func is_subscene() -> bool:
	return scene_file_path and self != get_tree().edited_scene_root


func _defer_refresh_on_change() -> void:
	if _dirty:
		return
	elif not is_node_ready():
		return # assume it'll be called by the main ready function once, well, ready
	elif _auto_refresh:
		_dirty = true
		call_deferred("_dirty_rebuild_deferred")
	else: # We would have done a rebuild if auto_refresh, so set the flag.
		_needs_refresh = true


# ------------------------------------------------------------------------------
#endregion
#region Exporter getter/setters
# ------------------------------------------------------------------------------


func _set_gen_ai_lanes(value: bool) -> void:
	if value == generate_ai_lanes:
		return
	generate_ai_lanes = value
	_defer_refresh_on_change()


func _set_ai_lane_group(value: String) -> void:
	if value == ai_lane_group:
		return
	ai_lane_group = value
	_defer_refresh_on_change()


func _set_auto_free_vehicles(value: bool) -> void:
	if value == auto_free_vehicles:
		return
	auto_free_vehicles = value
	for seg in get_segments():
		for _lane in seg.get_lanes():
			_lane.auto_free_vehicles = value


func _set_collider_group(value: String) -> void:
	if value == collider_group_name:
		return
	collider_group_name = value
	_defer_refresh_on_change()


func _set_collider_meta(value: String) -> void:
	if value == collider_group_name:
		return
	collider_meta_name = value
	_defer_refresh_on_change()


func _set_density(value) -> void:
	if value == density:
		return
	density = value
	_defer_refresh_on_change()


func effective_density() -> float:
	if density > 0.0:
		return density
	var manager = get_manager()
	if is_instance_valid(manager) and manager.density > 0.0:
		return manager.density
	else:
		return RoadSegment.DEFAULT_DENSITY


func _set_thickness(value) -> void:
	if value == underside_thickness:
		return
	underside_thickness = value
	_defer_refresh_on_change()


func _set_material(value) -> void:
	if value == material_resource:
		return
	material_resource = value
	update_material_overrides()
	_defer_refresh_on_change()


## Returns the effective material to apply to a child mesh of this container
##
## If no override is set on this container, will use the RoadManager's
func effective_surface_material() -> Material:
	if material_resource:
		return material_resource
	elif is_instance_valid(_manager) and _manager.material_resource:
		return _manager.material_resource
	return null


func _set_material_underside(value) -> void:
	if value == material_underside:
		return
	material_underside = value
	update_material_overrides()
	_defer_refresh_on_change()


## Returns the effective material to apply to a child mesh of this container
##
## If no override is set on this container, will use the RoadManager's
func effective_underside_material() -> Material:
	if material_underside:
		return material_underside
	elif is_instance_valid(_manager) and _manager.material_underside:
		return _manager.material_underside
	return null


func _dirty_rebuild_deferred() -> void:
	if not is_node_ready():
		return
	if _dirty:
		_dirty = false
		call_deferred("rebuild_segments", true)


func _set_draw_lanes_editor(value: bool):
	if value == _draw_lanes_editor:
		return
	_draw_lanes_editor = value
	for seg in get_segments():
		if not generate_ai_lanes:
			seg.clear_lane_segments()
		seg.update_lane_visibility() # could still have some manually added
	for inter in get_intersections():
		inter.update_lane_visibility()


func _get_draw_lanes_editor() -> bool:
	return _draw_lanes_editor


func _set_draw_lanes_game(value: bool):
	if value == _draw_lanes_game:
		return
	_draw_lanes_game = value
	for seg in get_segments():
		seg.update_lane_visibility()
	for inter in get_intersections():
		inter.update_lane_visibility()


func _get_draw_lanes_game() -> bool:
	return _draw_lanes_game


func _set_create_geo(value: bool) -> void:
	if value == create_geo:
		return
	create_geo = value
	for ch in get_children():
		# Cyclic loading, have to use workaround
		if ch is RoadPoint:
			for rp_ch in ch.get_children():
				# Cycling loading, have to use workaround
				if rp_ch.has_method("is_road_segment"):
					rp_ch.do_roadmesh_creation()
		if ch is RoadIntersection:
			ch._do_roadmesh_creation()
	if value == true:
		_dirty = true
		call_deferred("_dirty_rebuild_deferred")


func _set_create_edge_curves(value: bool) -> void:
	if value == create_edge_curves:
		return
	create_edge_curves = value
	if create_edge_curves:
		for seg in get_segments():
			seg.generate_edge_curves()
		for inter in get_intersections():
			inter.generate_edge_curves()
	else:
		for seg in get_segments():
			seg.clear_edge_curves()
		for inter in get_intersections():
			inter.clear_edge_curves()


# ------------------------------------------------------------------------------
#endregion
#region Editor interactions
# ------------------------------------------------------------------------------


func _notification(what):
	if what == NOTIFICATION_TRANSFORM_CHANGED and Engine.is_editor_hint():
		var lmb_down = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
		if lmb_down and not _drag_init_transform:
			self._drag_init_transform = global_transform
		elif not lmb_down:
			on_transform.emit(self)
			var manager = get_manager()
			if is_instance_valid(manager):
				manager.on_container_transformed.emit(self)
			_drag_init_transform = null


# ------------------------------------------------------------------------------
#endregion
#region Public Getter Functions
# ------------------------------------------------------------------------------


## Get the highest-level RoadManager parent to this node.
##
## If multiple in hiearchy, the top-most one will be used.
func get_manager() -> RoadManager: # -> Optional[RoadManager]
	var _this_manager:RoadManager = null
	var _last_par = get_parent()
	while true:
		if _last_par == null or not _last_par.is_inside_tree():
			break
		if _last_par.get_path() == ^"/root":
			break
		if _last_par is RoadManager:
			_this_manager = _last_par
		_last_par = _last_par.get_parent()
	_manager = _this_manager
	return _manager


func get_roadpoints(skip_edge_connected=false) -> Array[RoadPoint]:
	var rps: Array[RoadPoint] = []
	for obj in get_children():
		if not obj is RoadPoint:
			continue
		if not obj.visible:
			continue # Assume local chunk has dealt with the geo visibility.
		if obj.is_queued_for_deletion():
			continue # To be cleaned up anyways
		var pt:RoadPoint = obj
		rps.append(pt)

	if skip_edge_connected:
		# Filter out pts which shouldn't be lane-changed (ie due to containers)
		for itm in rps:
			if itm.cross_container_connected():
				rps.erase(itm)

	return rps


func get_intersections() -> Array[RoadIntersection]:
	var results: Array[RoadIntersection] = []
	for obj in get_children():
		if not obj is RoadIntersection:
			continue
		if not obj.visible:
			continue # Assume local chunk has dealt with the geo visibility.
		if obj.is_queued_for_deletion():
			continue # To be cleaned up anyways
		var inters:RoadIntersection = obj
		results.append(inters)
	return results


## Returns all RoadSegments which are directly children of RoadPoints.
##
## Will not return RoadSegmetns of nested scenes, presumed to be static.
func get_segments() -> Array:
	var segs = []
	for ch in get_children():
		if not ch is RoadPoint:
			continue
		for pt_ch in ch.get_children():
			if not pt_ch is RoadSegment:
				continue
			if pt_ch.is_queued_for_deletion():
				continue
			segs.append(pt_ch)
	return segs


## Recursively gets all RoadContainers within a root node
func get_all_road_containers(root: Node) -> Array[RoadContainer]:
	var nodes: Array[RoadContainer] = []
	var dist: float

	for n in root.get_children():
		if n.get_child_count() > 0:
			if n.has_method("is_road_container"):
				var pt: RoadContainer = n
				nodes.append(pt)
			nodes.append_array(get_all_road_containers(n))
		else:
			if n.has_method("is_road_container"):
				var pt: RoadContainer = n
				nodes.append(pt)
	return nodes


## Get Edge RoadPoints that are open and available for connections
func get_open_edges() -> Array[RoadPoint]:
	var rp_edges: Array[RoadPoint] = []
	for idx in len(edge_rp_locals):
		var edge: RoadPoint = get_node_or_null(edge_rp_locals[idx])
		var edge_cont: RoadContainer = get_node_or_null(edge_containers[idx])
		if edge_cont:
			# Edge is already connected
			continue
		elif edge and edge.terminated:
			# Edge is terminated (TODO: remove this branch, should not longer be in edge list now)
			continue
		elif edge:
			# Edge is available for connections
			rp_edges.append(edge)
		else:
			# Edge is non-existent
			continue
	return rp_edges


## Get RoadPoint closest to this global 3D position
func get_closest_graphnode(g_search_pos: Vector3, ignore_node: RoadGraphNode = null, include_intersections: bool = true) -> RoadGraphNode:
	var nodes: Array[RoadGraphNode] = []
	for _node in get_roadpoints():
		if _node == ignore_node:
			continue
		nodes.append(_node)
	if include_intersections:
		for _node in get_intersections():
			if _node == ignore_node:
				continue
			nodes.append(_node)
	return _cloest_graph_node(g_search_pos, nodes)


## Get edge RoadPoint closest to this global 3D position.
func get_closest_edge_road_point(g_search_pos: Vector3, ignore_rp: RoadPoint = null) -> RoadPoint:
	var nodes: Array[RoadGraphNode] = []
	for _node in get_open_edges():
		if _node == ignore_rp:
			continue
		nodes.append(_node)
	return _cloest_graph_node(g_search_pos, nodes) as RoadPoint


func _cloest_graph_node(g_search_pos: Vector3, reference_rps: Array[RoadGraphNode]) -> RoadGraphNode:
	var closest_rp: RoadPoint
	var closest_dist: float

	for rp in reference_rps:
		var this_dist = g_search_pos.distance_squared_to(rp.global_position)
		if not closest_dist or this_dist < closest_dist:
			closest_dist = this_dist
			closest_rp = rp
	return closest_rp


## Get Edge RoadPoints that are unavailable for connections. Returns structure of
## [local Edges, target Edges, and target containers].
func get_connected_edges() -> Array:
	var rp_edges: Array = []
	for idx in len(edge_rp_locals):
		var edge: RoadPoint = get_node_or_null(edge_rp_locals[idx])
		var target_cont: RoadContainer = get_node_or_null(edge_containers[idx])
#		var is_scene =
		# Find out if the target container is a scene
		if target_cont and target_cont.scene_file_path:
			print("%s %s is a scene %s" % [Time.get_ticks_msec(), target_cont.name, target_cont.scene_file_path])
#		else:
#			print("target_cont is null")
		if not target_cont:
			continue
		var target: RoadPoint = target_cont.get_node_or_null(edge_rp_targets[idx])
		if target and edge:
			# Edge is already connected
			rp_edges.append([edge, target, target_cont])
		elif edge and edge.terminated:
			# Edge is terminated
			continue
		elif edge:
			# Edge is available for connections
			continue
		else:
			# Edge is non-existent
			continue
	return rp_edges


## Returns array of connected Edges that are not in a nested scene.
func get_moving_edges() -> Array:
	var rp_edges: Array = []
	for rp in get_connected_edges():
		var edge: RoadPoint = rp[0]
		var target: RoadPoint = rp[1]
		var target_cont: RoadContainer = rp[2]
		# Skip Edge if target container is nested scene
		if target_cont and target_cont.is_subscene():
			continue
		# Add Edge to list
		rp_edges.append([edge, target, target_cont])
	return rp_edges


# ------------------------------------------------------------------------------
#endregion
#region Public Operators
# ------------------------------------------------------------------------------


## Check for any invalid connections between containers
##
## Checks to see that connections are reciprocol.
## Returns true if any invalid/autofixed (reciprocol disconnection)
func validate_edges(autofix: bool = false) -> bool:
	var is_valid := true
	for _idx in range(len(edge_rp_locals)):
		var this_pt_path = edge_rp_locals[_idx]

		# Pre-check, ensure local node paths are good.
		var this_pt = get_node_or_null(this_pt_path)
		if not is_instance_valid(this_pt):
			is_valid = false
			_invalidate_edge(_idx, autofix, "edge_rp_local node reference is invalid")
			continue

		var this_dir = edge_rp_local_dirs[_idx]
		var target_pt = edge_rp_targets[_idx]
		var target_dir = edge_rp_target_dirs[_idx]
		var target = null  # the presumed connected RP.

		if this_dir == this_pt.PointInit.NEXT:
			if this_pt.next_pt_init != ^"":
				# Shouldn't be marked as connecting to another local pt, "" indicates edge pt.
				is_valid = false
				_invalidate_edge(_idx, autofix, "next_pt_init should be empty for this edge's next pt")
				continue
			else:
				target = this_pt.get_next_road_node()
		elif this_dir == this_pt.PointInit.PRIOR:
			if this_pt.prior_pt_init != ^"":
				# Shouldn't be marked as connecting to another local pt, "" indicates edge pt.
				is_valid = false
				_invalidate_edge(_idx, autofix, "prior_pt_init should be empty for this edge's prior pt")
				continue
			else:
				target = this_pt.get_prior_road_node()
		elif this_dir == -1:
			# The local dir should never be -1, since it's defined locally.
			is_valid = false
			_invalidate_edge(_idx, autofix, "edge_rp_local_dir is -1, should not happen")
			continue
		else:
			# Invalid value assigned for direction.
			is_valid = false
			_invalidate_edge(_idx, autofix, "edge_rp_local_dirs value invalid")
			continue

		if edge_containers[_idx] != ^"":
			# Connection should be there, verify values.
			var cont = get_node_or_null(edge_containers[_idx])
			if not is_instance_valid(cont):
				is_valid = false
				_invalidate_edge(_idx, autofix, "edge_container reference not valid")
				continue

			var tg_node = cont.get_node_or_null(target_pt)
			if not is_instance_valid(tg_node):
				is_valid = false
				_invalidate_edge(_idx, autofix, "edge_rp_target reference not valid")
				continue
			if not target_dir in [tg_node.PointInit.NEXT, tg_node.PointInit.PRIOR]:
				is_valid = false
				_invalidate_edge(_idx, autofix, "edge_rp_target_dirs value invalid")
				continue

			var tg_ready = is_instance_valid(tg_node.container) and tg_node.container.is_node_ready()
			var this_ready = is_instance_valid(this_pt.container) and this_pt.container.is_node_ready()
			if not tg_ready or not this_ready:
				continue

			# check they occupy the same position / size / etc
			if tg_node.global_transform.origin != this_pt.global_transform.origin:
				var loc_diff = tg_node.global_transform.origin - this_pt.global_transform.origin
				if loc_diff.length() < 0.001:
					pass  # floating point rounding margin
				elif autofix:
					snap_and_update(tg_node, this_pt)
					continue
				else:
					# don't auto-clear this ever, as it's not related to export var references
					is_valid = false
					_invalidate_edge(_idx, false, "Edge points don't occupy the same location: %s/%s and %s/%s" % [
						tg_node.container.name, tg_node.name, this_pt.container.name, this_pt.name
					])
					continue

		else:
			# If edge_container is empty, then ensure that RP in that direction
			# does not think it's connected.
			pass
	if is_valid:
		_edge_error = ""
	elif debug:
		print("Found invalid edges on %s" % self.name)
	return is_valid


## Moves RoadPoints connected to this container if this is
## a nested scene and target is not a nested scene.
func move_connected_road_points():
	# Bail if this is not a nested scene
	if not is_subscene():
		return
	# Iterate only moving RoadPoints
	for rp in get_moving_edges():
		var sel_rp: RoadPoint = rp[0]
		var tgt_rp: RoadPoint = rp[1]
		# Move connected RoadPoint
		tgt_rp.global_transform = sel_rp.global_transform

		# Add 180 degrees to Y rotation if needed
		var is_prior_prior: bool = sel_rp.next_pt_init and tgt_rp.next_pt_init
		var is_next_next: bool = sel_rp.prior_pt_init and tgt_rp.prior_pt_init
		if is_prior_prior or is_next_next:
			var basis_y = sel_rp.global_transform.basis.y
			sel_rp.rotate(basis_y, PI)


## Update export variable lengths and counts to account for connection to
## other RoadContainers
func update_edges():
	# TODO: Optomize parent callers to avoid re-calls, e.g. on save.
	#print("Debug: Updating container edges %s" % self.name)

	var _tmp_containers:Array[NodePath] = []
	var _tmp_rp_targets:Array[NodePath] = []
	var _tmp_rp_target_dirs:Array[int] = []
	var _tmp_rp_locals:Array[NodePath] = []
	var _tmp_rp_local_dirs:Array[int] = []

	for ch in get_roadpoints():
		var pt:RoadPoint = ch
		if pt.terminated:
			# Terminated points should not be counted as external edges
			continue

		for this_dir in [RoadPoint.PointInit.NEXT, RoadPoint.PointInit.PRIOR]:
			var is_edge := false
			var dir_pt_init
			if this_dir == RoadPoint.PointInit.PRIOR:
				dir_pt_init = pt.prior_pt_init
			else:
				dir_pt_init = pt.next_pt_init

			if dir_pt_init == ^"":
				# Set this rp to indicate its next point is the container,
				# making it aware it is an "edge".
				is_edge = true
			elif dir_pt_init == pt.get_path_to(self):
				# Already self identified as an edge as connected to this container
				is_edge = true
			else:
				# Must be 'interior' as it is connected but not to container
				is_edge = false

			if is_edge == false:
				continue

			_tmp_rp_locals.append(self.get_path_to(pt))
			_tmp_rp_local_dirs.append(this_dir)

			# Lookup pre-existing connections to apply, match of name + dir
			var idx = -1
			for _find_idx in len(edge_rp_locals):
				if _find_idx >= len(edge_rp_locals) or _find_idx >= len(edge_rp_local_dirs):
					break
				if edge_rp_locals[_find_idx] != self.get_path_to(pt):
					continue
				if edge_rp_local_dirs[_find_idx] != this_dir:
					continue
				idx = _find_idx
				break

			if idx >= 0 and len(edge_containers) > idx:
				_tmp_containers.append(edge_containers[idx])
				_tmp_rp_targets.append(edge_rp_targets[idx])
				_tmp_rp_target_dirs.append(edge_rp_target_dirs[idx])
			else:
				_tmp_containers.append(^"")
				_tmp_rp_targets.append(^"")
				_tmp_rp_target_dirs.append(-1) # -1 to mean an unconnected index, since valid enums are 0+

	# Finally, do a near-synchronous update of the export var references
	edge_containers = _tmp_containers
	edge_rp_targets = _tmp_rp_targets
	edge_rp_target_dirs = _tmp_rp_target_dirs
	edge_rp_locals = _tmp_rp_locals
	edge_rp_local_dirs = _tmp_rp_local_dirs


## Removes a single RoadSegment, ensuring no leftovers and signal is emitted.
func remove_segment(seg:RoadSegment) -> void:
	if not seg or not is_instance_valid(seg):
		push_warning("RoadSegment is invalid, cannot remove: ")
		#print("Did NOT signal for the removal here", seg)
		return
	seg.clear_lane_segments()
	var id := seg.get_id()
	seg.queue_free()
	segid_map.erase(id)

	# If this function is triggered by during an onpoint update (such as
	# setting next_pt_init to ""), then this would be a repeat signal call.
	#emit_signal("on_road_updated", [])


## Transforms sel_rp's parent road container such that sel_rp is perfectly
## aligned (or flip-aligned) with tgt_rp
func snap_to_road_point(sel_rp: RoadPoint, tgt_rp: RoadPoint) -> void:
	var res := get_transform_for_snap_rp(sel_rp, tgt_rp)
	global_transform = res[0]
	var sel_dir:int = res[1]
	var tgt_dir:int = res[2]
	sel_rp.connect_container(sel_dir, tgt_rp, tgt_dir)


func get_transform_for_snap_rp(src_rp: RoadPoint, tgt_rp: RoadPoint) -> Array:
	var rp_trans:Transform3D = src_rp.global_transform
	var tgt_trans:Transform3D = tgt_rp.global_transform
	var cont_trans:Transform3D = global_transform

	var start_dir: int
	var end_dir: int

	# Add 180 degrees to Y rotation if needed
	var is_prior_prior: bool = src_rp.next_pt_init and tgt_rp.next_pt_init
	var is_next_next: bool = src_rp.prior_pt_init and tgt_rp.prior_pt_init
	if is_prior_prior or is_next_next:
		tgt_trans.basis = tgt_trans.basis.rotated(tgt_trans.basis.y, PI) # fkip around y
	if is_next_next:
		start_dir = RoadPoint.PointInit.NEXT
		end_dir = RoadPoint.PointInit.NEXT
	elif is_prior_prior:
		start_dir = RoadPoint.PointInit.PRIOR
		end_dir = RoadPoint.PointInit.PRIOR
	elif not src_rp.next_pt_init:
		start_dir = RoadPoint.PointInit.NEXT
		end_dir = RoadPoint.PointInit.PRIOR
	else:
		start_dir = RoadPoint.PointInit.PRIOR
		end_dir = RoadPoint.PointInit.NEXT

	var transform_difference = tgt_trans * rp_trans.affine_inverse()

	# Return structure designed to enable new placement and calling src_rp.connect_container
	return [transform_difference * cont_trans, start_dir, end_dir]


## Attempt to relocate a given pair of RoadPoints to each other with aligned settings.
##
## Useful to fix or update after the transformation of points / road containers
## with connections to other containers.
func snap_and_update(rp_a: Node, rp_b: Node) -> void:
	if debug:
		print("Snapping %s and %s" % [rp_a.name, rp_b.name])
	var rpa_sub = rp_a.container.is_subscene()
	var rpb_sub = rp_b.container.is_subscene()
	if rpa_sub and rpb_sub:
		push_warning("Cannot snap together two RoadPoints both of saved subscenes")
		return

	var src_pt
	var tgt_pt

	# Prefer to snap the other point to this one, since this one is most likely
	# the one which was just (intentionally) moved by the user.
	if rpb_sub:
		src_pt = rp_b
		tgt_pt = rp_a
	else: # rpa_sub is true or both not subscenes: move B (exterior) to A (selected container)
		src_pt = rp_a
		tgt_pt = rp_b
	if debug:
		print("Snapping %s/%s to position/settings of %s/%s" % [
			tgt_pt.container.name, tgt_pt.name, src_pt.container.name, src_pt.name])

	# Update all other settings; this (possibly badly!) assumes that the
	# edge being updated is oriented the same way as the source (ie prio -> next)
	tgt_pt._is_internal_updating = true
	tgt_pt._is_internal_updating = true
	tgt_pt.global_transform = src_pt.global_transform
	tgt_pt.copy_settings_from(src_pt)
	tgt_pt._is_internal_updating = false
	tgt_pt._is_internal_updating = false
	# Trigger emit_transform only once
	# tgt_pt.emit_transform() causes crashing, but is *definitely* in need of refreshing.


## Update the lane_next and lane_prior connections based on tags assigned.
##
## Process over each end of "connecting" Lanes, therefore best to iterate
## over RoadPoints.
func update_lane_seg_connections():
	for obj in get_children():
		if not obj is RoadPoint:
			continue
		if not obj.visible:
			continue # Assume local chunk has dealt with the geo visibility.
		if obj.is_queued_for_deletion():
			continue # To be cleaned up anyways
		var pt:RoadPoint = obj

		# update prior lanes to match next lanes first.
		var prior_valid = pt.prior_seg and is_instance_valid(pt.prior_seg)
		var next_valid = pt.next_seg and is_instance_valid(pt.next_seg)

		if not (prior_valid and next_valid):
			# Nothing to update
			# TODO: technically should clear next lane and prior lanes,
			# but for now since lanes are re-generated each time, there's no
			# risk of having faulty connections.
			continue

		var prior_seg_lanes = pt.prior_seg.get_lanes()
		var next_seg_lanes = pt.next_seg.get_lanes()

		# Check lanes attributed to the *prior* segment
		for prior_ln in prior_seg_lanes:
			# prior lane be set to track to a next lane
			for next_ln in next_seg_lanes:
				if is_instance_valid(next_ln.owner):
					# Don't auto update paths owned by the editor
					continue
				if prior_ln.lane_next_tag == next_ln.lane_prior_tag:
					# TODO: When directionality is made consistent, we should no longer
					# need to invert the direction assignment here.
					if prior_ln.lane_next_tag[0] == "F":
						prior_ln.lane_prior = prior_ln.get_path_to(next_ln)
						next_ln.lane_next = next_ln.get_path_to(prior_ln)
					else:
						assert(prior_ln.lane_next_tag[0] == "R")
						prior_ln.lane_next = prior_ln.get_path_to(next_ln)
						next_ln.lane_prior = next_ln.get_path_to(prior_ln)


## Configures roadcontainer owner and assigns material if necessary
func setup_road_container():

	# In order for points and segments to show up in the Scene dock, they must
	# be assigned an "owner". Use the RoadContainer's owner. But, the RoadContainer
	# won't have an owner if it is the scene root. In that case, make the
	# RoadContainer the owner.
	var own
	if owner:
		own = owner
	else:
		own = self

	if not is_instance_valid(get_manager()) and not material_resource:
		# Assign a road material by default if there's no parent RoadManager
		material_resource = RoadMaterial


func update_material_overrides() -> void:
	for _mesh in material_top_meshes:
		if not is_instance_valid(_mesh) or not _mesh is MeshInstance3D:
			push_warning("Non mesh assigned in RoadContainer %s: material_top_meshes " % self.name)
			continue
		_mesh.set_surface_override_material(0, material_resource)


## Recusrvely return all collision objects on this container, procedural or hand-added
func get_collision_nodes() -> Array[CollisionObject3D]:
	var coll_objs: Array[CollisionObject3D] = []
	var next_iter:Array = get_children()
	while not next_iter.is_empty():
		var tmp_iter: Array = next_iter.duplicate()
		next_iter = []
		for ch in tmp_iter:
			if ch is CollisionObject3D:
				coll_objs.append(ch)
			next_iter.append_array(ch.get_children())
	return coll_objs


# ------------------------------------------------------------------------------
#endregion
#region Geometry update
# ------------------------------------------------------------------------------


## Triggered by adjusting RoadPoint transform in editor via signal connection.
func on_point_update(node:RoadGraphNode, low_poly:bool) -> void:
	if not _auto_refresh:
		_needs_refresh = true
		return
	elif not is_instance_valid(node):
		# TODO: update this
		return
	# Update warnings for this or connected containers
	if node is RoadIntersection:
		var inter:RoadIntersection = node
		inter.is_dirty = true
		var was_rebuilt := inter.check_rebuild()
		if was_rebuilt:
			_emit_road_updated([inter])
		return
	var point: RoadPoint = node as RoadPoint
	if point.is_on_edge():
		#var prior = point.get_prior_road_node()
		#var next = point.get_next_road_node()
		# TODO: Need to trigger transform updates on these nodes,
		# without triggering emit_transform etc, these turn into infinite loops or godot crashes
		#if is_instance_valid(prior) and prior.container != self:
		#	snap_and_update(point, prior) # many prop changes, ensure internal skip
		#if is_instance_valid(next) and next.container != self:
		#	snap_and_update(point, next) # many prop changes, ensure internal skip

		point.container.validate_edges()  # could still have problems, if both are subscene.

	var segs_updated = []  # For signal emission
	var res

	if _auto_refresh:
		point.validate_junctions()
	var use_lowpoly = low_poly and use_lowpoly_preview
	
	if is_instance_valid(point.prior_seg):
		point.prior_seg.low_poly = use_lowpoly
		point.prior_seg.is_dirty = true
		point.prior_seg.call_deferred("check_rebuild")
		segs_updated.append(point.prior_seg)  # Track an updated RoadSegment
	elif point.get_node_or_null(point.prior_pt_init) and point.get_node_or_null(point.prior_pt_init).visible:
		var prior = point.get_node_or_null(point.prior_pt_init)
		if not is_instance_valid(prior):
			push_warning("Auto-cleared invalid prior_pt_init %s on %s" % [point.prior_pt_init, point.name])
			point.prior_pt_init = ^""
		elif prior.has_method("is_road_point"):  # ie skip road container.
			res = _process_seg(prior, point, use_lowpoly)
			if res[0] == true:
				segs_updated.append(res[1])  # Track an updated RoadSegment
		elif prior is RoadIntersection:
			var inter:RoadIntersection = prior
			inter.is_dirty = true
			var was_rebuilt := inter.check_rebuild()
			if was_rebuilt:
				segs_updated.append(inter)

	if is_instance_valid(point.next_seg):
		point.next_seg.low_poly = use_lowpoly
		point.next_seg.is_dirty = true
		point.next_seg.call_deferred("check_rebuild")
		segs_updated.append(point.next_seg)  # Track an updated RoadSegment
	elif point.get_node_or_null(point.next_pt_init) and point.get_node_or_null(point.next_pt_init).visible:
		var next = point.get_node_or_null(point.next_pt_init)
		if not is_instance_valid(next):
			push_warning("Auto-cleared invalid next_pt_init %s on %s" % [point.next_pt_init, point.name])
			point.next_pt_init = ^""
		elif next.has_method("is_road_point"):  # ie skip road container.
			res = _process_seg(point, next, use_lowpoly)
			if res[0] == true:
				segs_updated.append(res[1])  # Track an updated RoadSegment
		elif next is RoadIntersection:
			var inter:RoadIntersection = next
			inter.is_dirty = true
			var was_rebuilt := inter.check_rebuild()
			if was_rebuilt:
				segs_updated.append(inter)

	if len(segs_updated) > 0:
		_emit_road_updated(segs_updated)

## Adds all pre-existing RoadLanes to the target group and meta tag
##
## Mostly for editor-define lanes to ensure the groups are added, since they
## may be children of RoadPoints that don't
func force_assign_lanes() -> void:
	var rps := get_roadpoints()
	var mgr := get_manager()
	var lanes: Array[RoadLane] = []

	# First, get all RoadLanes that are children of detected RoadPoints
	for _rp in rps:
		for _rl in _rp.get_children():
			if not _rl is RoadLane:
				continue
			lanes.append(_rl)

	# Then RoadLanes that are children of intersections
	for _inter in get_intersections():
		for _rl in _inter.get_children():
			if not _rl is RoadLane:
				continue
			lanes.append(_rl)

	# Now get loose, direct child RoadLanes of container
	for _ch in get_children():
		if not _ch is RoadLane:
			continue
		lanes.append(_ch)

	for _rl in lanes:
		if ai_lane_group != "":
			# Poentially check not already in the group
			_rl.add_to_group(ai_lane_group)
		elif is_instance_valid(mgr) and mgr.ai_lane_group != "":
			_rl.add_to_group(mgr.ai_lane_group)


## Makes the calls to (re)build geometry on all child RoadSegments/Intersections
func rebuild_segments(clear_existing := false):
	if not is_inside_tree() or not is_node_ready():
		# This most commonly happens in the editor on project restart, where
		# each opened scene tab is quickly loaded and then apparently unloaded,
		# so tab one last saved as not active will defer call rebuild, and by
		# the time rebuild_segments occurs, it has already been disable.
		# With this early return, we avoid all the issues of this nature:
		# Cannot get path of node as it is not in a scene tree.
		# scene/3d/spatial.cpp:407 - Condition "!is_inside_tree()" is true. Returned: Transform()
		return
	var manager = get_manager()
	if is_instance_valid(manager):
		if not manager.is_node_ready():
			# Defer segment building
			return
	update_edges()
	validate_edges(clear_existing)
	
	_needs_refresh = false
	if debug:
		print("Rebuilding RoadSegments %s" % self.name)

	if clear_existing:
		segid_map = {}
		for ch in get_segments():
			ch.queue_free()
	else:
		# TODO: think of using groups instead, to have a single manager
		# that is not dependent on this parenting structure.
		pass

	# Goal is to loop through all RoadPoints, and check if an existing segment
	# is there, or needs to be added.
	var rebuilt = 0
	var signal_rebuilt = []
	for obj in get_roadpoints():
		var pt:RoadPoint = obj

		var prior_pt
		var next_pt
		if pt.prior_pt_init:
			prior_pt = pt.get_node_or_null(pt.prior_pt_init)
			if not is_instance_valid(prior_pt) or not prior_pt is RoadGraphNode:
				prior_pt = null
		if pt.next_pt_init:
			next_pt = pt.get_node_or_null(pt.next_pt_init)
			if not is_instance_valid(next_pt) or not next_pt is RoadGraphNode:
				next_pt = null

		if not prior_pt and not next_pt:
			push_warning("Road point %s/%s not connected to anything yet" % [pt.get_parent().name, pt.name])
			continue
		var res
		if prior_pt is RoadPoint and prior_pt.visible:
			res = _process_seg(prior_pt, pt)
			if res[0] == true:
				rebuilt += 1
				signal_rebuilt.append(res[1])
		if next_pt is RoadPoint and next_pt.visible:
			res = _process_seg(pt, next_pt)
			if res[0] == true:
				rebuilt += 1
				signal_rebuilt.append(res[1])

	for _inter in get_intersections():
		var inter:RoadIntersection = _inter
		inter.sort_branches()
		if clear_existing:
			inter.is_dirty = true
		var was_rebuilt := inter.check_rebuild()
		if was_rebuilt:
			signal_rebuilt.append(inter)

	# After intial lanes are added, ensure the manually defined ones are in
	# the group. Intentioanlly adding this later, so they aren't picked first
	force_assign_lanes()

	# Once all RoadSegments (and their lanes) exist, update next/prior lanes.
	# Update even if generate_ai_lanes off, could have added manually / made editable
	update_lane_seg_connections()
	if signal_rebuilt.size() > 0:
		_emit_road_updated(signal_rebuilt)


## Callback from a modification of a RoadSegment object.
func segment_rebuild(road_segment:RoadSegment):
	road_segment.check_rebuild()


## Create a new road segment based on input prior and next RoadPoints.
## Returns Array[was_updated: bool, RoadSegment]
func _process_seg(pt1:RoadPoint, pt2:RoadPoint, low_poly:bool=false) -> Array:
	var sid = RoadSegment.get_id_for_points(pt1, pt2)
	if sid in segid_map and is_instance_valid(segid_map[sid]):
		var was_rebuilt = segid_map[sid].check_rebuild()
		return [was_rebuilt, segid_map[sid]]
	else:
		var new_seg = RoadSegment.new(self)

		# Must not move from origin, else geometry offsets would occur. Also
		# implies to user to not interact with this item if ever exposed.
		new_seg.set_meta("_edit_lock_", true)
		new_seg.set_meta("_edit_group_", true)

		# We want to, as much as possible, deterministically add the RoadSeg
		# as a child of a consistent RoadPoint. Even though the segment is
		# connected to two road points, it will only be placed as a parent of
		# one of them
		pt1.add_child(new_seg)
		if debug_scene_visible:
			new_seg.owner = self.get_owner()
		new_seg.low_poly = low_poly
		new_seg.start_point = pt1
		new_seg.end_point = pt2
		if pt1.next_pt_init != pt1.get_path_to(pt2):
			new_seg._start_flip = true
		else:
			new_seg._start_flip = false
		if pt2.prior_pt_init != pt2.get_path_to(pt1):
			new_seg._end_flip = true
		else:
			new_seg._end_flip = false
		segid_map[sid] = new_seg

		new_seg.material = effective_surface_material()
		new_seg.material_underside = effective_underside_material()

		new_seg.check_rebuild()

		var segment_thickness: float
		#if
		# VISSA ANCHOR POINT

		return [true, new_seg]


# ------------------------------------------------------------------------------
#endregion
#region Private functions
# ------------------------------------------------------------------------------


## A data cleanup way to clear invalid edges.
##
## Normally would use a roadpoint's disconnect_container function,
## but if there's data inconsistency, we need to manually clear connections.
func _invalidate_edge(_idx, autofix: bool, reason=""):
	# First, try to clear the reciprocol container.
	_edge_error = reason
	var reason_str = "" if reason == "" else " due to %s" % reason
	if _drag_init_transform:
		# We are mid-drag, so don't mess with edges yet
		return
	push_warning("Invalid cross-container connection, %s with edge index %s%s" % [
		self.name, _idx, reason_str
	])
	if not autofix:
		return
	edge_containers[_idx] = ^""
	edge_rp_targets[_idx] = ^""
	edge_rp_target_dirs[_idx] = -1


func _create_collisions(road_mesh: MeshInstance3D) -> void:
	for ch in road_mesh.get_children():
		ch.queue_free()  # Prior collision meshes

	var manager = get_manager()

	# Could also manually create with Mesh.create_trimesh_shape(),
	# but this is still advertised as a non-cheap solution.
	road_mesh.create_trimesh_collision()
	for ch in road_mesh.get_children():
		var sbody := ch as StaticBody3D # Set to null if casting fails
		if not sbody:
			continue

		if collider_group_name != "":
			sbody.add_to_group(collider_group_name)
		elif is_instance_valid(manager) and manager.collider_group_name != "":
			sbody.add_to_group(manager.collider_group_name)

		if collider_meta_name != "":
			sbody.set_meta(collider_meta_name, true)
		elif is_instance_valid(manager) and manager.collider_meta_name != "":
			sbody.set_meta(manager.collider_meta_name, true)

		if physics_material != null:
			sbody.physics_material_override = physics_material
		elif is_instance_valid(manager) and manager.physics_material != null:
			sbody.physics_material_override = manager.physics_material

		if override_collision_layers:
			sbody.collision_layer = collision_layer
			sbody.collision_mask = collision_mask
		elif is_instance_valid(manager):
			sbody.collision_layer = manager.collision_layer
			sbody.collision_mask = manager.collision_mask
		# else: will just be the godot default.

		sbody.set_meta("_edit_lock_", true)


## Signals the segments whichhave been just (re)built
func _emit_road_updated(segments: Array) -> void:
	if self.debug:
		print_debug("RoadSegments rebuilt: ", len(segments))
	on_road_updated.emit(segments)
	if is_instance_valid(_manager):
		_manager.on_container_update(segments)


#endregion
# ------------------------------------------------------------------------------
