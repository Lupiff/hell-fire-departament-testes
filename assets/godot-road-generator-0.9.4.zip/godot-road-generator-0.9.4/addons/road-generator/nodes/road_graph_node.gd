@tool
@icon("res://addons/road-generator/resources/road_point.png")
class_name RoadGraphNode
extends Node3D
## Abstract base class for defining road points.
##
## @abstract
##
## Abstract base class for defining road points, existing mostly
## for typing reasons. As such, logic should remain to the strict minimum.


var container:RoadContainer ## The managing container node for this node (direct parent).
