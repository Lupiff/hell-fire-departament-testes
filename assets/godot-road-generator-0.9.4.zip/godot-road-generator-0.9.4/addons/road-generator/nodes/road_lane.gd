@tool
@icon("res://addons/road-generator/resources/road_lane.png")
class_name RoadLane
extends Path3D
## Defines a directional lane of traffic for AI with references to adjacent lanes.
##
## These are generated as children of [RoadPoint]'s automatically if its given
## [member RoadContainer.generate_ai_lanes] is set to true.
##
## @tutorial(Using RoadLanes with custom meshes): https://github.com/TheDuckCow/godot-road-generator/wiki/User-guide:-Custom-road-meshes
## @tutorial(Procedural demo with agents): https://github.com/TheDuckCow/godot-road-generator/tree/main/demo/procedural_generator

# ------------------------------------------------------------------------------
#region Signals/Enums/Const
# ------------------------------------------------------------------------------


signal on_transform

const COLOR_PRIMARY := Color(0.6, 0.3, 0,3)
const COLOR_START := Color(0.1, 0.9, 0.0)
const COLOR_END := Color(0.8, 0.1, 0.1) #Color(0.4, 0.7, 0,7)


# ------------------------------------------------------------------------------
#endregion
#region Export vars
# ------------------------------------------------------------------------------


# -------------------------------------
@export_group("Connections")
# -------------------------------------


## Reference to the next left-side [RoadLane] if any, for allowed lane transitions.
@export var lane_left:NodePath
## Reference to the next right-side [RoadLane] if any, for allowed lane transitions.
@export var lane_right:NodePath
## The next forward [RoadLane] for agents to follow along.
@export var lane_next:NodePath
## The prior [RoadLane] for agents to follow (if going backwards).
@export var lane_prior:NodePath

## Tags are used help populate the lane_next and lane_prior NodePaths above.[br][br]
##
## Given two segments (seg_A followed by seg_B), a lane_A of seg_A will be auto
## matched to lane_B of seg_B if lane_A's lane_next_tag is the same as lane_B's
## lane_prior_tag (since lane_B follows lane_A in this situation).[br][br]
##
## Any matching name will do, and it will match the first match. Auto-generated
## lanes have a convention of a prefix F or R (for forward or reverse lane,
## relative to the road segment) followed by a 0-indexed integer, based on how
## far from the middle of the road (middle = where the lane direction flips).[br][br]
##
## This way, the inner most lanes are always matched together. A lane F2 being
## removed on the right (forward) will be recognized as needing to have it's
## lane_next_tag set to F1, representing cars merging from this removed lane into
## the next interior lane.[br][br]
##
## e.g. R0, R1,...R#, F0, F1, ... F#.
@export var lane_next_tag:String
## See description above for [member RoadLane.lane_next_tag] which is the equivalent.
@export var lane_prior_tag:String


# -------------------------------------
@export_group("Behavior")
# -------------------------------------

## Visualize this [RoadLane] and its direction in the editor directly.
@export var draw_in_game = false: get = _get_draw_in_game, set = _set_draw_in_game
## Visualize this [RoadLane] and its direction during the game runtime.
@export var draw_in_editor = false: get = _get_draw_in_editor, set = _set_draw_in_editor

## Mesh instanced along the lane to visualize its direction. All lanes share
## the same resource by default; assign another mesh to customize the shape.
@export var lane_pointer_mesh: Mesh = preload("res://addons/road-generator/resources/road_lane_pointer_mesh.res"): set = _set_lane_pointer_mesh

## Auto queue-free any vehicles registered to this lane with the road lane exits.
@export var auto_free_vehicles: bool = true


# -------------------------------------
@export_group("Editor tools")
# -------------------------------------


# TODO: remove when moved to Godot 4.4 and changed to simple button
# the variable is not used - only to provide GUI element
## UI tool to easily flip the order of points of the curve.[br][br]
##
## Property will remain unchecked but will perform the action described. Will be
## replaced with a tool button once this addon targets Godot 4.4 as the minimum.
@export var reverse_direction = false: set = _set_reverse_direction


var road_segment = null ## Will be populatd at runtime if an auto generated lane
var refresh_geom = true
var geom:MultiMesh # For tool usage, drawing lane directions and end points
var geom_node: MultiMeshInstance3D
# Internal field used by agents for intra-segment lane changes
var transition: bool = false

var _vehicles_in_lane = [] # Registration
var _draw_in_game: bool = false
var _draw_in_editor: bool = false
var _draw_override: bool = false
var _display_fins: bool = false


# ------------------------------------------------------------------------------
#endregion
#region Setup and builtin overrides
# ------------------------------------------------------------------------------


func _init():
	if not is_instance_valid(curve):
		curve = Curve3D.new()


func _ready():
	set_notify_transform(true)
	set_notify_local_transform(true)
	connect("curve_changed", Callable(self, "curve_changed"))
	rebuild_geom()
	#_instantiate_geom()


func _exit_tree() -> void:
	if auto_free_vehicles:
		for _vehicle in _vehicles_in_lane:
			if is_instance_valid(_vehicle):
				_vehicle.call_deferred("queue_free")


# ------------------------------------------------------------------------------
#endregion
#region Functions
# ------------------------------------------------------------------------------


#TODO: remove when moved to Godot 4.4 and changed to simple button
func _set_reverse_direction(value: bool) -> void:
	on_reverse_lane()


## Reverse geometry of lane curve
func on_reverse_lane() -> void:
	var reversed_curve = Curve3D.new()
	for i in range(self.curve.point_count - 1, -1, -1):
		var pos = self.curve.get_point_position(i)
		var in_tangent = self.curve.get_point_in(i)
		var out_tangent = self.curve.get_point_out(i)
		reversed_curve.add_point(pos, out_tangent, in_tangent)
	self.curve = reversed_curve
	refresh_geom = true
	rebuild_geom()


func get_lane_start() -> Vector3:
	return to_global(curve.get_point_position(0))


func get_lane_end() -> Vector3:
	return to_global(curve.get_point_position(curve.get_point_count()-1))


## Register a car to be connected to (on, following) this lane.
func register_vehicle(vehicle: Node) -> void:
	_vehicles_in_lane.append(vehicle)


## Optional but good cleanup of references.
func unregister_vehicle(vehicle: Node) -> void:
	if vehicle in _vehicles_in_lane:
		_vehicles_in_lane.erase(vehicle)


## Return all vehicles registered to this lane, performing cleanup as needed.
func get_vehicles() -> Array:
	for vehicle in _vehicles_in_lane:
		if (not is_instance_valid(vehicle)) or vehicle.is_queued_for_deletion():
			_vehicles_in_lane.erase(vehicle)
			continue
	return _vehicles_in_lane


func _instantiate_geom() -> void:

	if Engine.is_editor_hint():
		_display_fins = _draw_in_editor or _draw_override
	else:
		_display_fins = _draw_in_game or _draw_override

	if not _display_fins:
		if geom:
			geom.instance_count = 0
		return
	if refresh_geom == false:
		return
	refresh_geom = false

	# Setup geo node if not already.
	if geom == null:
		geom = MultiMesh.new()
		geom.set_name("geom")
		geom.transform_format = MultiMesh.TRANSFORM_3D
		geom.use_colors = true
		geom.mesh = lane_pointer_mesh
		if not is_instance_valid(geom_node):
			geom_node = MultiMeshInstance3D.new()
			geom_node.multimesh = geom
			add_child(geom_node)
		else:
			geom_node.multimesh = geom

		var mat = StandardMaterial3D.new()
		mat.flags_unshaded = true
		mat.flags_disable_ambient_light = true
		mat.params_depth_draw_mode = StandardMaterial3D.DEPTH_DRAW_DISABLED
		mat.flags_do_not_receive_shadows = true
		mat.flags_no_depth_test = true
		mat.flags_do_not_receive_shadows = true
		mat.params_cull_mode = mat.CULL_DISABLED
		mat.vertex_color_use_as_albedo = true
		geom_node.material_override = mat

	_draw_shark_fins()


## Place pointer mesh instances along the path, indicating lane direction.
func _draw_shark_fins() -> void:
	var curve_length := curve.get_baked_length()
	var draw_dist := 1 # place a new pointer at this interval in m
	var tri_count: int = floor(curve_length / draw_dist)

	if tri_count == 0 or lane_pointer_mesh == null:
		geom.instance_count = 0
		return
	geom.mesh = lane_pointer_mesh
	# Forward extent of the pointer, to pin the last one against the lane end.
	var pointer_length: float = lane_pointer_mesh.get_aabb().size.z
	geom.instance_count = tri_count
	for i in range (0, tri_count):
		var f: float = i * curve_length / tri_count
		if i == tri_count - 1:
			# Land the end pointer's tip on the lane end, nudging the next
			# lane's start pointer.
			f = maxf(curve_length - pointer_length, 0.0)
		var origin: Vector3 = curve.sample_baked(f)
		# use sample_baked_with_rotation?
		var lookat: Vector3 = (
			curve.sample_baked(f + 0.1) - origin
		).normalized()
		var upvec := curve.sample_baked_up_vector(f, true).normalized()

		var basis := Basis()
		if lookat.length_squared() > 0.5 and absf(lookat.dot(upvec)) < 0.999:
			basis = Basis.looking_at(lookat, upvec)
		geom.set_instance_transform(i, Transform3D(basis, origin))

		if i == 0:
			geom.set_instance_color(i, COLOR_START)
		elif i == tri_count - 1:
			geom.set_instance_color(i, COLOR_END)
		else:
			geom.set_instance_color(i, COLOR_PRIMARY)


func rebuild_geom() -> void:
	if refresh_geom:
		call_deferred("_instantiate_geom")


func curve_changed() -> void:
	refresh_geom = true
	rebuild_geom()


func _set_lane_pointer_mesh(value: Mesh) -> void:
	lane_pointer_mesh = value
	refresh_geom = true
	rebuild_geom()


func _set_draw_in_game(value: bool) -> void:
	refresh_geom = true
	_draw_in_game = value
	rebuild_geom()

func _get_draw_in_game() -> bool:
	return _draw_in_game

func _set_draw_in_editor(value: bool) -> void:
	refresh_geom = true
	_draw_in_editor = value
	rebuild_geom()

func _get_draw_in_editor() -> bool:
	return _draw_in_editor


func show_fins(value: bool) -> void:
	_draw_override = value
	rebuild_geom()


#endregion
# ------------------------------------------------------------------------------
