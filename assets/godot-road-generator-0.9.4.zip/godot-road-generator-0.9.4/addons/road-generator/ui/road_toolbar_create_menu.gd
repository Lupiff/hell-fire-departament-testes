@tool
extends MenuButton

signal regenerate_pressed
signal select_container_pressed
signal create_container
signal create_roadpoint
signal create_lane
signal create_lane_agent
signal create_terrain3d_connector
signal create_2x2_road
signal export_mesh
signal make_lanes_editable
signal feedback_pressed
signal report_issue_pressed


# ripple up from children
signal pressed_add_custom_roadcontainer(path)

enum CreateMenu {
	REGENERATE,
	SELECT_CONTAINER,
	CONTAINER,
	POINT,
	LANE,
	LANEAGENT,
	TERRAIN3D_CONNECTOR,
	TWO_X_TWO,
	EXPORT_MESH,
	MAKE_LANES_EDITABLE,
	FEEDBACK,
	REPORT_ISSUE
}

enum MenuMode {
	STANDARD,
	SAVED_SUBSCENE,  # Don't offer to create children
	EDGE_SELECTED,  # Not yet used, could offer intersections/next pieces to add.
}

const ICN_CT = preload("../resources/road_container.png")
const ICN_RP = preload("../resources/road_point.png")
const ICN_LN = preload("../resources/road_lane.png")
const ICN_AG = preload("../resources/road_lane_agent.png")
const RcSubMenu = preload("./rc_submenu.gd")

var menu_mode = MenuMode.STANDARD
var rc_submenu: PopupMenu


func _enter_tree() -> void:
	var pup: Popup = get_popup()

	pup.id_pressed.connect(_create_menu_item_clicked)

	if not is_instance_valid(rc_submenu):
		load_submenu()


func _exit_tree() -> void:
	get_popup().id_pressed.disconnect(_create_menu_item_clicked)


func load_submenu() -> void:
	var pup: Popup = get_popup()
	rc_submenu = RcSubMenu.new()
	rc_submenu.pressed_add_custom_roadcontainer.connect(_on_pressed_add_custom_roadcontainer)
	pup.add_child(rc_submenu)


func on_toolbar_show(primary_sel: Node) -> void:
	if primary_sel.has_method("is_subscene") and primary_sel.is_subscene():
		menu_mode = MenuMode.SAVED_SUBSCENE
	else:
		menu_mode = MenuMode.STANDARD

	var pup: PopupMenu = get_popup()

	# this prevents the menu from closing when a check item is clicked
	pup.hide_on_checkable_item_selection = false

	pup.clear()

	var idx:int = 0
	pup.add_item("Refresh roads", CreateMenu.REGENERATE)
	pup.set_item_tooltip(idx, "Re-generate geometry and resolve warnings")
	idx += 1
	pup.add_item("Select container", CreateMenu.SELECT_CONTAINER)
	pup.set_item_tooltip(idx, "Select this RoadPoint's parent RoadContainer")

	#if menu_mode == MenuMode.SAVED_SUBSCENE:
	#	# Don't offer to modify subscenes
	#	return

	# Set icon width so that it's scaled for the UI properly
	# Though it would seem like DisplayServer.screen_get_scale() would be good to
	# use, it seems that the icon scale is already correctly handled on mac OSX
	# even when setting a single size on 1x vs 2x monitors, and the function
	# is itself not implemented on windows. Thus, we'll just assign values based
	# on OS, since 32x looks too large on windows.
	var width := 32 if OS.get_name() == "macOS" else 16

	idx += 1
	pup.add_separator()

	idx += 1
	pup.add_icon_item(ICN_CT, "RoadContainer", CreateMenu.CONTAINER)
	pup.set_item_icon_max_width(idx, width)
	pup.set_item_tooltip(idx, "Adds a RoadContainer child to RoadManager")

	idx += 1
	pup.add_icon_item(ICN_RP, "RoadPoint", CreateMenu.POINT)
	pup.set_item_icon_max_width(idx, width)
	pup.set_item_tooltip(idx, "Adds a new RoadPoint")

	idx += 1
	pup.add_icon_item(ICN_LN, "RoadLane (AI path)", CreateMenu.LANE)
	pup.set_item_icon_max_width(idx, width)
	pup.set_item_tooltip(idx, "Adds a RoadLane which can be used for AI paths")

	idx += 1
	pup.add_icon_item(ICN_AG, "RoadLaneAgent (AI)", CreateMenu.LANEAGENT)
	pup.set_item_icon_max_width(idx, width)
	pup.set_item_tooltip(idx, "Adds a RoadLaneAgent to follow RoadLane paths")

	idx += 1
	pup.add_item("RoadTerrain3DConnector", CreateMenu.TERRAIN3D_CONNECTOR)
	pup.set_item_tooltip(idx, "Adds node to flatten Terrain3D surface based on roads")

	idx += 1
	pup.add_separator()

	idx += 1
	pup.add_item("2x2 road", CreateMenu.TWO_X_TWO)
	pup.set_item_tooltip(idx, "Adds a segment of road with 2 lanes each way")

	# rc_items must be name of the child of this menu
	if not is_instance_valid(rc_submenu):
		load_submenu()

	idx += 1
	rc_submenu.name = "rc_items"
	pup.add_submenu_item("RoadContainer presets", "rc_items", idx)

	idx += 1
	pup.add_separator()

	idx += 1
	pup.add_item("Export RoadContainer", CreateMenu.EXPORT_MESH)
	if not primary_sel is RoadContainer:
		pup.set_item_disabled(idx, true)
		pup.set_item_tooltip(idx, "Must have a RoadContainer selected")
	else:
		pup.set_item_tooltip(idx, "Export current RoadContainer and children to a gLTF/GLB file")
	
	idx += 1
	pup.add_item("Make RoadLanes Editable", CreateMenu.MAKE_LANES_EDITABLE)
	pup.set_item_tooltip(idx, "Expose RoadLanes nodes in editor for manual editing")
	if primary_sel is RoadContainer:
		if not primary_sel.generate_ai_lanes:
			pup.set_item_disabled(idx, true)
			pup.set_item_tooltip(idx, "Lanes disabled, nothing to make editable")
	elif primary_sel is RoadPoint:
		if not primary_sel.container.generate_ai_lanes:
			pup.set_item_disabled(idx, true)
			pup.set_item_tooltip(idx, "Lanes disabled, nothing to make editable")
	else:
		pup.set_item_disabled(idx, true)
		pup.set_item_tooltip(idx, "Only supported for RoadContainers and RoadPoints")

	idx += 1
	pup.add_separator()
	idx += 1
	pup.add_item("Report issue", CreateMenu.REPORT_ISSUE)
	idx += 1
	pup.add_item("Share feedback", CreateMenu.FEEDBACK)


func _create_menu_item_clicked(id: int) -> void:
	match id:
		CreateMenu.REGENERATE:
			regenerate_pressed.emit()
		CreateMenu.SELECT_CONTAINER:
			select_container_pressed.emit()
		CreateMenu.CONTAINER:
			create_container.emit()
		CreateMenu.POINT:
			create_roadpoint.emit()
		CreateMenu.LANE:
			create_lane.emit()
		CreateMenu.LANEAGENT:
			create_lane_agent.emit()
		CreateMenu.TERRAIN3D_CONNECTOR:
			create_terrain3d_connector.emit()
		CreateMenu.TWO_X_TWO:
			create_2x2_road.emit()
		CreateMenu.EXPORT_MESH:
			export_mesh.emit()
		CreateMenu.MAKE_LANES_EDITABLE:
			make_lanes_editable.emit()
		CreateMenu.FEEDBACK:
			feedback_pressed.emit()
		CreateMenu.REPORT_ISSUE:
			report_issue_pressed.emit()


## Toggle the given check item and return its new state
func _toggle_check_item(id: int) -> bool:
	var pup: PopupMenu = get_popup()
	var index = pup.get_item_index(id)
	var new_checked = not pup.is_item_checked(index)
	pup.set_item_checked(index, new_checked)
	return new_checked


func _on_pressed_add_custom_roadcontainer(path:String) -> void:

	pressed_add_custom_roadcontainer.emit(path)
